output_states = 6                                                                            # Number of Classes
image_size = 32                                                                              # Size of images before they enter network (or smallest dimension of image)

layer_limit = 8                                                                              # Max number of layers
                                                                 
possible_preFEBlock_ids = [1, 2, 3]
possible_FEBlock_ids = [1, 2]
possible_TBlock_ids = [1, 2, 3]
possible_CBlock_ids = [1, 2]

init_utility = 0.3                                                                          # Set this to around the performance of an average model. It is better to undershoot this


epsilon_schedule = [[1.0, 400],
                    [0.9, 40],
                    [0.8, 40],
                    [0.7, 40],
                    [0.6, 60],
                    [0.5, 60],
                    [0.4, 60],
                    [0.3, 60],
                    [0.2, 60],
                    [0.1, 60]]

# Q-Learning Hyper parameters
learning_rate = 0.01                                                                          # Q Learning learning rate (alpha)
discount_factor = 1.0                                                                         # Q Learning discount factor (gamma)
replay_number = 20                                                                            # Number trajectories to sample for replay at each iteration




