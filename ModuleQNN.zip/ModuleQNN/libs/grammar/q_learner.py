import math
import numpy as np
import pandas as pd
import os
from operator import itemgetter

import state_enumerator as se
from state_string_utils import StateStringUtils

class QValues:
    ''' Stores Q_values with helper functions.'''
    def __init__(self):
        self.q = {}

    def load_q_values(self, q_csv_path):
        self.q = {}
        q_csv = pd.read_csv(q_csv_path)
        for row in zip(*[q_csv[col].values.tolist() for col in ['start_block_type',
                                              'start_block_depth',
                                              'start_block_id',
                                              'end_block_type',
                                              'end_block_depth',
                                              'end_block_id',
                                              'utility']]):
            start_state = se.State(block_type = row[0],
                                   block_depth = row[1],
                                   block_id = row[2]).as_tuple()
            end_state = se.State(block_type = row[3],
                                 block_depth = row[4],
                                 block_id = row[5]).as_tuple()
            utility = row[6]

            if start_state not in self.q:
                self.q[start_state] = {'actions': [end_state], 'utilities': [utility]}
            else:
                self.q[start_state]['actions'].append(end_state)
                self.q[start_state]['utilities'].append(utility)


    def save_to_csv(self, q_csv_path):
        start_block_type = []
        start_block_depth = []
        start_block_id = []
        end_block_type = []
        end_block_depth = []
        end_block_id = []
        utility = []
        for start_state_list in self.q.keys():
            start_state = se.State(state_list=start_state_list)
            for to_state_ix in range(len(self.q[start_state_list]['actions'])):
                to_state = se.State(state_list=self.q[start_state_list]['actions'][to_state_ix])
                utility.append(self.q[start_state_list]['utilities'][to_state_ix])
                start_block_type.append(start_state.block_type)
                start_block_depth.append(start_state.block_depth)
                start_block_id.append(start_state.block_id)
                end_block_type.append(to_state.block_type)
                end_block_depth.append(to_state.block_depth)
                end_block_id.append(to_state.block_id)

        q_csv = pd.DataFrame({'start_block_type' : start_block_type,
                              'start_block_depth' : start_block_depth,
                              'start_block_id' : start_block_id,
                              'end_block_type' : end_block_type,
                              'end_block_depth' : end_block_depth,
                              'end_block_id' : end_block_id,
                              'utility' : utility})
        q_csv.to_csv(q_csv_path, index=False)

class QLearner:
    ''' All Q-Learning updates and policy generator

        Args
            state: The starting state for the QLearning Agent
            q_values: A dictionary of q_values -- 
                            keys: State tuples (State.as_tuple())
                            values: [state list, qvalue list]
            replay_dictionary: A pandas dataframe with columns: 'net' for net strings, and 'accuracy_best_val' for best accuracy
                                        and 'accuracy_last_val' for last accuracy achieved

            output_number : number of output neurons
    '''
    def __init__(self,
                 state_space_parameters, 
                 epsilon,
                 state=None,
                 qstore=None,
                 replay_dictionary=pd.DataFrame(columns=['net',
                                                         'accuracy_best_val',
                                                         'ix_q_value_update',
                                                         'epsilon'])):
        self.state_list = []

        self.state_space_parameters = state_space_parameters

        # Class that will expand states for us
        self.enum = se.StateEnumerator(state_space_parameters)
        self.stringutils = StateStringUtils(state_space_parameters)

        # Starting State
        self.state = se.State('start', 0, 0) if not state else state
        self.bucketed_state = self.enum.bucket_state(self.state)


        # Cached Q-Values -- used for q learning update and transition
        self.qstore = QValues() if not qstore else qstore
        self.replay_dictionary = replay_dictionary

        self.epsilon=epsilon # epsilon: parameter for epsilon greedy strategy

    def update_replay_database(self, new_replay_dic):
        self.replay_dictionary = new_replay_dic

    def generate_net(self):
        # Have Q-Learning agent sample current policy to generate a network and convert network to string format
        self._reset_for_new_walk()
        state_list = self._run_agent()
        # print(state_list)
        net_string = self.stringutils.state_list_to_string(state_list)
        # print(net_string)

        # Check if we have already trained this model
        if net_string in self.replay_dictionary['net'].values:
            acc_best_val = self.replay_dictionary[self.replay_dictionary['net']==net_string]['accuracy_best_val'].values[0]
            iter_best_val = self.replay_dictionary[self.replay_dictionary['net'] == net_string]['iter_best_val'].values[0]
        else:
            acc_best_val = -1.0
            iter_best_val = -1.0


        return (net_string, acc_best_val, iter_best_val)

    def save_q(self, q_path):
        self.qstore.save_to_csv(os.path.join(q_path,'q_values.csv'))

    def _reset_for_new_walk(self):
        '''Reset the state for a new random walk'''
        # Architecture String
        self.state_list = []

        # Starting State
        self.state = se.State('start', 0, 0)
        self.bucketed_state = self.enum.bucket_state(self.state)

    def _run_agent(self):
        ''' Have Q-Learning agent sample current policy to generate a network
        '''
        # while self.state.terminate == 0:
        while self.state.block_type != 'endBlock':
            self._transition_q_learning()

        # print(self.state_list)
        return self.state_list

    def _transition_q_learning(self):
        ''' Updates self.state according to an epsilon-greedy strategy'''
        if self.bucketed_state.as_tuple() not in self.qstore.q:
            self.enum.enumerate_state(self.bucketed_state, self.qstore.q)


        action_values = self.qstore.q[self.bucketed_state.as_tuple()]

        # epsilon greedy choice
        if np.random.random() < self.epsilon:
            action = se.State(state_list=action_values['actions'][np.random.randint(len(action_values['actions']))])
        else:
            max_q_value = max(action_values['utilities'])
            max_q_indexes = [i for i in range(len(action_values['actions'])) if action_values['utilities'][i]==max_q_value]
            max_actions = [action_values['actions'][i] for i in max_q_indexes]
            action = se.State(state_list=max_actions[np.random.randint(len(max_actions))])

        self.state = self.enum.state_action_transition(action)
        self.bucketed_state = self.enum.bucket_state(self.state)


        self._post_transition_updates()

    def _post_transition_updates(self):
        #State to go in state list
        bucketed_state = self.bucketed_state.copy()

        self.state_list.append(bucketed_state)

    def sample_replay_for_update(self):
        # Experience replay to update Q-Values
        for i in range(self.state_space_parameters.replay_number):
            net = np.random.choice(self.replay_dictionary['net'])
            accuracy_best_val = self.replay_dictionary[self.replay_dictionary['net'] == net]['accuracy_best_val'].values[0]
            state_list = self.stringutils.convert_model_string_to_states(net)

            # Convert States so they are bucketed
            state_list = [self.enum.bucket_state(state) for state in state_list]

            self.update_q_value_sequence(state_list, self.accuracy_to_reward(accuracy_best_val))


    def accuracy_to_reward(self, acc):
        '''How to define reward from accuracy'''
        return acc

    def update_q_value_sequence(self, states, termination_reward):
        '''Update all Q-Values for a sequence.'''
        for i in reversed(range(len(states) - 1)):
            reward = termination_reward / (len(states) -1)  # T = len(states) -1, meaning the number of action selection
            if states[i+1].block_type == 'endBlock':
                reward = termination_reward  # the reward of terminal action selection is the real accuarcy reward on
            self._update_q_value(states[i], states[i+1], reward)


    def _update_q_value(self, start_state, to_state, reward):
        ''' Update a single Q-Value for start_state given the state we transitioned to and the reward. '''
        if start_state.as_tuple() not in self.qstore.q:
            self.enum.enumerate_state(start_state, self.qstore.q)
        if to_state.block_type != 'endBlock':
            if to_state.as_tuple() not in self.qstore.q:
                self.enum.enumerate_state(to_state, self.qstore.q)

        actions = self.qstore.q[start_state.as_tuple()]['actions']
        values = self.qstore.q[start_state.as_tuple()]['utilities']

        # update Q_value is different, has two method  # add 20190311
        # T - 1
        if to_state.block_type == 'endBlock':
            values[actions.index(to_state.as_tuple())] = (1 - self.state_space_parameters.learning_rate) * values[actions.index(to_state.as_tuple())] + self.state_space_parameters.learning_rate * reward

        # 1, 2, ... T-2
        else:
            max_reward_next_states = max(self.qstore.q[to_state.as_tuple()]['utilities'])  # get the maximum utility of next_state
            # Q_Learning update rule
            values[actions.index(to_state.as_tuple())] = (1 - self.state_space_parameters.learning_rate) * values[actions.index(to_state.as_tuple())] + self.state_space_parameters.learning_rate * (reward + self.state_space_parameters.discount_factor * max_reward_next_states)



        self.qstore.q[start_state.as_tuple()] = {'actions': actions, 'utilities': values}

    




