import math
import numpy as np
from operator import itemgetter

import state_enumerator as se

class StateStringUtils:
    ''' Contains all functions dealing with converting nets to net strings
        and net strings to state lists.
    '''
    def __init__(self, state_space_parameters):
        self.image_size = state_space_parameters.image_size
        self.output_number = state_space_parameters.output_states
        self.enum = se.StateEnumerator(state_space_parameters)


    def state_list_to_string(self, state_list):
        '''Convert the list of strings to a string we can train from according to the grammar'''
        out_string = ''
        strings = []
        i = 0
        while i < len(state_list):
            state = state_list[i]
            if self.state_to_string(state):
                strings.append(self.state_to_string(state))
            i += 1
        return str('[' + ', '.join(strings) + ']')

    def state_to_string(self, state):
        ''' Returns the string asociated with state.
        '''
        if state.block_type == 'CBlock':
            return str(state.block_id)
        elif state.block_type == 'preFEBlock':
            return str(state.block_id)
        elif state.block_type == 'FEBlock':
            return str(state.block_id)
        elif state.block_type == 'TBlock':
            return str(state.block_id)
        return None

    def convert_model_string_to_states(self, net, start_state=None):
        '''Takes a parsed model string and returns a recursive list of states.'''

        states = [start_state] if start_state else [se.State('start', 0, 0)]

        net_code = eval(net)
        code_len = len(net_code)

        if code_len == 4:
            states.append(se.State(block_type='preFEBlock',
                                   block_depth=1,
                                   block_id=net_code[0]))
            states.append(se.State(block_type='TBlock',
                                   block_depth=2,
                                   block_id=net_code[1]))
            states.append(se.State(block_type='FEBlock',
                                   block_depth=3,
                                   block_id=net_code[2]))
            states.append(se.State(block_type='CBlock',
                                   block_depth=4,
                                   block_id=net_code[3]))

        elif code_len == 6:
            states.append(se.State(block_type='preFEBlock',
                                   block_depth=1,
                                   block_id=net_code[0]))
            states.append(se.State(block_type='TBlock',
                                   block_depth=2,
                                   block_id=net_code[1]))
            states.append(se.State(block_type='FEBlock',
                                   block_depth=3,
                                   block_id=net_code[2]))
            states.append(se.State(block_type='TBlock',
                                   block_depth=4,
                                   block_id=net_code[3]))
            states.append(se.State(block_type='FEBlock',
                                   block_depth=5,
                                   block_id=net_code[4]))
            states.append(se.State(block_type='CBlock',
                                   block_depth=6,
                                   block_id=net_code[5]))

        elif code_len == 8:
            states.append(se.State(block_type='preFEBlock',
                                   block_depth=1,
                                   block_id=net_code[0]))
            states.append(se.State(block_type='TBlock',
                                   block_depth=2,
                                   block_id=net_code[1]))
            states.append(se.State(block_type='FEBlock',
                                   block_depth=3,
                                   block_id=net_code[2]))
            states.append(se.State(block_type='TBlock',
                                   block_depth=4,
                                   block_id=net_code[3]))
            states.append(se.State(block_type='FEBlock',
                                   block_depth=5,
                                   block_id=net_code[4]))
            states.append(se.State(block_type='TBlock',
                                   block_depth=6,
                                   block_id=net_code[5]))
            states.append(se.State(block_type='FEBlock',
                                   block_depth=7,
                                   block_id=net_code[6]))
            states.append(se.State(block_type='CBlock',
                                   block_depth=8,
                                   block_id=net_code[7]))
    
        return states



