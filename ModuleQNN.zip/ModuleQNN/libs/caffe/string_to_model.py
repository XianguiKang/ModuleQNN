import math
import numpy as np
import os
import sys
import creat_block as cre


from libs.grammar.state_string_utils import StateStringUtils

caffe_root='/HDD/program/caffe'
import sys
sys.path.insert(0, caffe_root + 'python')
import caffe

from caffe import layers as L
from caffe import params as P
from caffe import to_proto



class Parser:
	def __init__(self, hyper_parameters, state_space_parameters):
		self.hp = hyper_parameters
		self.ssp = state_space_parameters

	def create_net(self, net_string, datapath, for_train):
		net = caffe.NetSpec()
		net.data, net.label = caffe.layers.ImageData(source=datapath, batch_size=self.hp.TRAIN_BATCH_SIZE, shuffle=True, ntop=2,
													 transform_param=dict(scale=0.00390625))

		net_code = eval(net_string)
		code_len = len(net_code)
		class_num = self.hp.NUM_CLASSES

		if code_len == 4:
			net.preout = cre.preFEBlock(net.data, net_code[0])
			net.trans1 = cre.TBlock(net.preout, net_code[1])
			net.dense1 = cre.FEBlock(net.trans1, net_code[2])
			net.ip = cre.CBlock(net.dense1, net_code[code_len-1], class_num)
		elif code_len == 6:
			net.preout = cre.preFEBlock(net.data, net_code[0])
			net.trans1 = cre.TBlock(net.preout, net_code[1])
			net.dense1 = cre.FEBlock(net.trans1, net_code[2])
			net.trans2 = cre.TBlock(net.dense1, net_code[3])
			net.dense2 = cre.FEBlock(net.trans2, net_code[4])
			net.ip = cre.CBlock(net.dense2, net_code[code_len-1], class_num)
		elif code_len == 8:
			net.preout = cre.preFEBlock(net.data, net_code[0])
			net.trans1 = cre.TBlock(net.preout, net_code[1])
			net.dense1 = cre.FEBlock(net.trans1, net_code[2])
			net.trans2 = cre.TBlock(net.dense1, net_code[3])
			net.dense2 = cre.FEBlock(net.trans2, net_code[4])
			net.trans3 = cre.TBlock(net.dense2, net_code[5])
			net.dense3 = cre.FEBlock(net.trans3, net_code[6])
			net.ip = cre.CBlock(net.dense3, net_code[code_len-1], class_num)
		if for_train:
			net.loss = L.SoftmaxWithLoss(net.ip, net.label, include=dict(phase=caffe.TRAIN))
		else:
			net.loss = L.SoftmaxWithLoss(net.ip, net.label, include=dict(phase=caffe.TEST))
		net.acc = L.Accuracy(net.ip, net.label)
		return net.to_proto()

	def creat_new_layer(self,net, substr, newstr, layernum):
		net = net.replace(substr, newstr, layernum)
		return net


	def create_caffe_spec(self, net_string, netspec_path, testpro_path):
		with open(netspec_path, 'w') as f:
			net = str(self.create_net(net_string, self.hp.TRAIN_FILE, for_train=True))
			net_code = eval(net_string)
			f.write(net)


		with open(testpro_path, 'w') as f:
			net = str(self.create_net(net_string, self.hp.TEST_FILE, for_train=False))
			net_code = eval(net_string)
			f.write(net)








