caffe_root = '/HDD/program/caffe/'
import sys
sys.path.insert(0, caffe_root + 'python')
from caffe import layers as L,params as P
import caffe



'''
preFEBlock means the first three types of FE-modules. The input images are first passed to an preFEBlock to
extract features.
'''
def preFEBlock(input,id):
    if id == 1:
        conv = L.Convolution(input, num_output=8, kernel_size=3, pad=1, stride=1,
                             weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                             param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
        bn_conv1 = L.BatchNorm(conv, use_global_stats=False, in_place=True,
                               batch_norm_param=dict(moving_average_fraction=0.05))
        conv1 = L.Convolution(bn_conv1, num_output=8, kernel_size=3, pad=1, stride=1,
                              weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                              param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
        bn_conv2 = L.BatchNorm(conv1, use_global_stats=False, in_place=True,
                               batch_norm_param=dict(moving_average_fraction=0.05))

        output = L.ReLU(bn_conv2, in_place=True)
    elif id == 2:
        conv = L.Convolution(input, num_output=8, kernel_size=3, pad=1, stride=1,
                             weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                             param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
        bn_conv = L.BatchNorm(conv, use_global_stats=False, in_place=True,
                              batch_norm_param=dict(moving_average_fraction=0.05))
        relu = L.ReLU(bn_conv, in_place=True)
        conv1 = L.Convolution(relu, num_output=8, kernel_size=3, pad=1, stride=1,
                              weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                              param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
        bn_conv1 = L.BatchNorm(conv1, use_global_stats=False, in_place=True,
                               batch_norm_param=dict(moving_average_fraction=0.05))
        relu1 = L.ReLU(bn_conv1, in_place=True)
        concat1 = L.Concat(relu, relu1, axis=1)
        conv2 = L.Convolution(concat1, num_output=8, kernel_size=3, pad=1, stride=1,
                              weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                              param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
        bn_conv2 = L.BatchNorm(conv2, use_global_stats=False, in_place=True,
                               batch_norm_param=dict(moving_average_fraction=0.05))
        relu2 = L.ReLU(bn_conv2, in_place=True)
        output = L.Concat(concat1, relu2, axis=1)
    elif id == 3:
        conv = L.Convolution(input, num_output=8, kernel_size=3, pad=1, stride=1,
                             weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                             param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
        bn_conv = L.BatchNorm(conv, use_global_stats=False, in_place=True,
                              batch_norm_param=dict(moving_average_fraction=0.05))
        relu = L.ReLU(bn_conv, in_place=True)
        conv1 = L.Convolution(relu, num_output=8, kernel_size=3, pad=1, stride=1,
                              weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                              param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
        bn_conv1 = L.BatchNorm(conv1, use_global_stats=False, in_place=True,
                               batch_norm_param=dict(moving_average_fraction=0.05))
        relu1 = L.ReLU(bn_conv1, in_place=True)
        concat1 = L.Concat(relu, relu1, axis=1)
        conv2 = L.Convolution(concat1, num_output=8, kernel_size=3, pad=1, stride=1,
                              weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                              param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
        bn_conv2 = L.BatchNorm(conv2, use_global_stats=False, in_place=True,
                               batch_norm_param=dict(moving_average_fraction=0.05))
        relu2 = L.ReLU(bn_conv2, in_place=True)
        concat2 = L.Concat(concat1, relu2, axis=1)
        conv3 = L.Convolution(concat2, num_output=8, kernel_size=3, pad=1, stride=1,
                              weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                              param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
        bn_conv3 = L.BatchNorm(conv3, use_global_stats=False, in_place=True,
                               batch_norm_param=dict(moving_average_fraction=0.05))
        output = L.Concat(concat2, relu3, axis=1)
    return output

def dense_block_one(input):
    conv1 = L.Convolution(input, num_output=32, kernel_size=3, pad=1, stride=1,
                         weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                         param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
    bn_conv1 = L.BatchNorm(conv1, use_global_stats=False, in_place=True,
                                          batch_norm_param=dict(moving_average_fraction=0.05))
    relu1 = L.ReLU(bn_conv1, in_place=True)
    concat1 = L.Concat(input, relu1, axis=1)
    conv2 = L.Convolution(concat1, num_output=32, kernel_size=3, pad=1, stride=1,
                         weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                         param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
    bn_conv2 = L.BatchNorm(conv2, use_global_stats=False, in_place=True,
                                          batch_norm_param=dict(moving_average_fraction=0.05))
    relu2 = L.ReLU(bn_conv2, in_place=True)
    dense_output = L.Concat(concat1, relu2, axis=1)
    return dense_output

def dense_block_two(input):
    conv1 = L.Convolution(input, num_output=32, kernel_size=3, pad=1, stride=1,
                         weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                         param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
    bn_conv1 = L.BatchNorm(conv1, use_global_stats=False, in_place=True,
                                          batch_norm_param=dict(moving_average_fraction=0.05))
    relu1 = L.ReLU(bn_conv1, in_place=True)
    concat1 = L.Concat(input, relu1, axis=1)
    conv2 = L.Convolution(concat1, num_output=32, kernel_size=3, pad=1, stride=1,
                         weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                         param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
    bn_conv2 = L.BatchNorm(conv2, use_global_stats=False, in_place=True,
                                          batch_norm_param=dict(moving_average_fraction=0.05))
    relu2 = L.ReLU(bn_conv2, in_place=True)
    concat2 = L.Concat(concat1, relu2, axis=1)
    conv3 = L.Convolution(concat2, num_output=32, kernel_size=3, pad=1, stride=1,
                         weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                         param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
    bn_conv3 = L.BatchNorm(conv3, use_global_stats=False, in_place=True,
                                          batch_norm_param=dict(moving_average_fraction=0.05))
    relu3= L.ReLU(bn_conv3, in_place=True)
    dense_output = L.Concat(concat2, relu3, axis=1)
    return dense_output

def FEBlock(input,id):
    if id == 1:
        output = dense_block_one(input)
    elif id == 2:
        output = dense_block_two(input)
    return output

def trans_max_pool(input):
    conv = L.Convolution(input, num_output=16, kernel_size=1, pad=0, stride=1,
                                          weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                                          param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
    bn_conv = L.BatchNorm(conv, use_global_stats=False, in_place=True,
                                           batch_norm_param=dict(moving_average_fraction=0.05))
    relu = L.ReLU(bn_conv, in_place=True)
    pool = L.Pooling(relu, pool=P.Pooling.MAX, pad=0, kernel_size=2, stride=2)
    return pool

def trans_ave_pool(input):
    conv = L.Convolution(input, num_output=16, kernel_size=1, pad=0, stride=1,
                                          weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                                          param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
    bn_conv = L.BatchNorm(conv, use_global_stats=False, in_place=True,
                                           batch_norm_param=dict(moving_average_fraction=0.05))
    relu = L.ReLU(bn_conv, in_place=True)
    pool = L.Pooling(relu, pool=P.Pooling.AVE, pad=0, kernel_size=2, stride=2)
    return pool

def trans_conv(input):
    conv1 = L.Convolution(input, num_output=16, kernel_size=1, pad=0, stride=1,
                                          weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                                          param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
    bn_conv1 = L.BatchNorm(conv1, use_global_stats=False, in_place=True,
                                           batch_norm_param=dict(moving_average_fraction=0.05))
    relu1 = L.ReLU(bn_conv1, in_place=True)
    conv2 = L.Convolution(relu1, num_output=16, kernel_size=3, pad=1, stride=2,
                                          weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                                          param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
    bn_conv2 = L.BatchNorm(conv2, use_global_stats=False, in_place=True,
                                           batch_norm_param=dict(moving_average_fraction=0.05))
    pool = L.ReLU(bn_conv2, in_place=True)
    return pool


def TBlock(input, id):
        if id == 1:
            output = trans_ave_pool(input)
        elif id == 2:
            output = trans_max_pool(input)
        elif id == 3:
            output = trans_conv(input)
    return output


'''
If the current state is the fourth type of T-modules, the next state is restricted to a C-module.
Therefore, the fourth T-module is incorporated into the C-module in the program implementation.
'''
def classifier_one(input, class_num):
    conv = L.Convolution(input, num_output=128, kernel_size=1, pad=0, stride=1,
                        weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                        param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
    bn_conv = L.BatchNorm(conv, use_global_stats=False, in_place=True,
                        batch_norm_param=dict(moving_average_fraction=0.05))
    relu = L.ReLU(bn_conv, in_place=True)
    pool = L.Pooling(relu, pool=P.Pooling.AVE, global_pooling=True)
    fc = L.InnerProduct(pool, num_output=class_num, weight_filler=dict(type='xavier'),
                       bias_filler={"type": "constant"})
    return fc

def classifier_two(input,class_num):
    conv = L.Convolution(input, num_output=128, kernel_size=1, pad=0, stride=1,
                             weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                             param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
    bn_conv = L.BatchNorm(conv, use_global_stats=False, in_place=True,
                              batch_norm_param=dict(moving_average_fraction=0.05))
    relu = L.ReLU(bn_conv, in_place=True)
    pool = L.Pooling(relu, pool=P.Pooling.AVE, global_pooling=True)
    fc1 = L.InnerProduct(pool, num_output=256, weight_filler=dict(type='xavier'),
                             bias_filler={"type": "constant"})
    fc = L.InnerProduct(fc1, num_output=class_num, weight_filler=dict(type='xavier'),
                            bias_filler={"type": "constant"})
    return fc


def CBlock(input,id, class_num):
    if id == 1:
        output = classifier_one(input,class_num)
    elif id == 2:
        output = classifier_two(input,class_num)   
    return output